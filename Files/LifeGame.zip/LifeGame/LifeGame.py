import sys
import random
import json
import os
import numpy as np
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QGridLayout,
    QHBoxLayout, QVBoxLayout, QPushButton, QSlider,
    QLabel, QScrollArea, QFrame, QButtonGroup, QRadioButton,
    QComboBox, QCheckBox, QDialog, QLineEdit, QColorDialog,
    QTabWidget, QListWidget, QListWidgetItem, QMessageBox,
    QSplitter, QMenu, QAction, QGroupBox, QSizePolicy
)
from PyQt5.QtCore import Qt, QTimer, QSize, pyqtSignal, QPointF
from PyQt5.QtGui import QPainter, QBrush, QPen, QColor, QFont, QTransform


class GameOfLife(QWidget):
    """康威生命游戏画布（稀疏存储，支持平移/缩放，NumPy 加速）"""
    grid_changed = pyqtSignal()

    def __init__(self, rows=10000, cols=10000, cell_size=12, parent=None, enable_view_transform=True):
        super().__init__(parent)
        self.rows = rows
        self.cols = cols
        self.base_cell_size = cell_size          # 基础单元格大小（像素）
        self.zoom = 1.0                           # 缩放因子
        self.offset_x = 0.0                        # 世界原点在屏幕上的 X 偏移
        self.offset_y = 0.0                        # 世界原点在屏幕上的 Y 偏移

        # 是否启用视图变换（用于预设编辑器等固定视图场景）
        self.enable_view_transform = enable_view_transform

        # 稀疏存储：存活细胞坐标的集合
        self.live_cells = set()

        # 外观颜色
        self.live_color = QColor(100, 255, 100)
        self.dead_color = QColor(30, 30, 30)
        self.grid_color = QColor(60, 60, 60)

        # 交互模式
        self.draw_mode = 'toggle'      # 'toggle', 'live', 'dead'
        self.show_grid = True
        self.boundary = 'wrap'          # 'wrap' 或 'fixed'
        self.density = 0.3

        # 右键拖拽相关
        self.dragging = False
        self.last_mouse_pos = None
        self.drag_start_offset = None

        # 左键绘制相关
        self.last_pos = None
        self.drawing_state = None

        # 启用鼠标追踪以接收移动事件
        self.setMouseTracking(True)

        # 设置控件大小策略，使其填充可用空间
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

        # 新增：粗网格线间隔（0表示不启用）
        self.thick_grid_step = 10

    def sizeHint(self):
        return QSize(800, 600)

    # -------------------- 视图变换辅助 --------------------
    def world_to_screen(self, r, c):
        """将世界坐标 (r, c) 转换为屏幕像素坐标 (x, y)"""
        x = c * self.base_cell_size * self.zoom + self.offset_x
        y = r * self.base_cell_size * self.zoom + self.offset_y
        return x, y

    def screen_to_world(self, x, y):
        """将屏幕像素坐标转换为世界坐标 (r, c)（浮点）"""
        c = (x - self.offset_x) / (self.base_cell_size * self.zoom)
        r = (y - self.offset_y) / (self.base_cell_size * self.zoom)
        return r, c

    # ========== 新增：将世界中心移动到视图中心 ==========
    def center_view(self, view_rect):
        """将世界中心 (rows/2, cols/2) 移动到 view_rect 的中心"""
        center_r = self.rows / 2.0
        center_c = self.cols / 2.0
        # 世界中心对应的屏幕坐标（使用当前缩放）
        screen_center_x = center_c * self.base_cell_size * self.zoom
        screen_center_y = center_r * self.base_cell_size * self.zoom
        # 我们希望屏幕中心 (view_rect.center()) 显示世界中心
        target_x = view_rect.center().x()
        target_y = view_rect.center().y()
        # 偏移量使得世界中心映射到目标点
        self.offset_x = target_x - screen_center_x
        self.offset_y = target_y - screen_center_y
        self.update()

    # -------------------- 绘制 --------------------
    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        # 背景（死细胞区域）
        painter.fillRect(self.rect(), self.dead_color)

        # 计算当前视口对应的世界坐标范围（加上一个单元格的缓冲，避免边缘闪烁）
        view_rect = self.rect()
        left = view_rect.left()
        top = view_rect.top()
        right = view_rect.right()
        bottom = view_rect.bottom()

        # 世界坐标范围（浮点）
        r_min, c_min = self.screen_to_world(left, top)
        r_max, c_max = self.screen_to_world(right, bottom)

        # 转换为整数索引，并扩展一个单元格
        r_min = int(max(0, r_min - 1))
        r_max = int(min(self.rows - 1, r_max + 1))
        c_min = int(max(0, c_min - 1))
        c_max = int(min(self.cols - 1, c_max + 1))

        # 绘制存活细胞（仅遍历视口内的细胞）
        brush_live = QBrush(self.live_color)
        cell_size_scaled = self.base_cell_size * self.zoom
        for r, c in self.live_cells:
            if r_min <= r <= r_max and c_min <= c <= c_max:
                x = c * cell_size_scaled + self.offset_x
                y = r * cell_size_scaled + self.offset_y
                painter.fillRect(int(x), int(y), int(cell_size_scaled), int(cell_size_scaled), brush_live)

        # 绘制网格线（可选）
        if self.show_grid and self.zoom > 0.5:  # 缩放太小时不画网格，避免密集线段
            # 预定义粗细画笔（颜色相同）
            pen_thin = QPen(self.grid_color, 1)
            pen_thick = QPen(self.grid_color, 2)

            # 计算需要绘制的网格线范围
            start_c = max(0, int(c_min))
            end_c = min(self.cols, int(c_max) + 1)
            start_r = max(0, int(r_min))
            end_r = min(self.rows, int(r_max) + 1)

            # 绘制垂直线
            for c in range(start_c, end_c + 1):
                x = c * cell_size_scaled + self.offset_x
                if left <= x <= right:
                    if self.thick_grid_step and c % self.thick_grid_step == 0:
                        painter.setPen(pen_thick)
                    else:
                        painter.setPen(pen_thin)
                    painter.drawLine(int(x), top, int(x), bottom)

            # 绘制水平线
            for r in range(start_r, end_r + 1):
                y = r * cell_size_scaled + self.offset_y
                if top <= y <= bottom:
                    if self.thick_grid_step and r % self.thick_grid_step == 0:
                        painter.setPen(pen_thick)
                    else:
                        painter.setPen(pen_thin)
                    painter.drawLine(left, int(y), right, int(y))

    # -------------------- 鼠标事件（平移/绘制）--------------------
    def mousePressEvent(self, event):
        if self.enable_view_transform and event.button() == Qt.RightButton:
            # 开始右键拖拽
            self.dragging = True
            self.last_mouse_pos = event.pos()
            self.drag_start_offset = (self.offset_x, self.offset_y)
            event.accept()
        elif event.button() == Qt.LeftButton:
            # 左键绘制
            world_r, world_c = self.screen_to_world(event.x(), event.y())
            r = int(world_r)
            c = int(world_c)
            if 0 <= r < self.rows and 0 <= c < self.cols:
                if self.draw_mode == 'toggle':
                    target = (r, c) not in self.live_cells
                elif self.draw_mode == 'live':
                    target = True
                else:
                    target = False

                if target:
                    self.live_cells.add((r, c))
                else:
                    self.live_cells.discard((r, c))
                self.update()
                self.grid_changed.emit()

                self.last_pos = (r, c)
                self.drawing_state = target
            event.accept()
        else:
            super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        if self.dragging and self.last_mouse_pos:
            # 右键拖拽平移
            delta = event.pos() - self.last_mouse_pos
            self.offset_x = self.drag_start_offset[0] + delta.x()
            self.offset_y = self.drag_start_offset[1] + delta.y()
            self.update()
            event.accept()
        elif self.last_pos is not None:
            # 左键绘制拖拽
            world_r, world_c = self.screen_to_world(event.x(), event.y())
            r = int(world_r)
            c = int(world_c)
            if 0 <= r < self.rows and 0 <= c < self.cols and (r, c) != self.last_pos:
                if self.drawing_state:
                    self.live_cells.add((r, c))
                else:
                    self.live_cells.discard((r, c))
                self.update()
                self.grid_changed.emit()
                self.last_pos = (r, c)
            event.accept()
        else:
            super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.RightButton:
            self.dragging = False
            self.last_mouse_pos = None
            self.drag_start_offset = None
            event.accept()
        else:
            self.last_pos = None
            self.drawing_state = None
            event.accept()

    def wheelEvent(self, event):
        if not self.enable_view_transform:
            event.ignore()
            return
        """鼠标滚轮缩放，以鼠标位置为中心"""
        zoom_factor = 1.1
        if event.angleDelta().y() > 0:
            # 放大
            new_zoom = self.zoom * zoom_factor
        else:
            # 缩小
            new_zoom = self.zoom / zoom_factor

        # 限制缩放范围
        new_zoom = max(0.1, min(10.0, new_zoom))

        # 鼠标位置（屏幕坐标）
        mouse_pos = event.pos()
        mx, my = mouse_pos.x(), mouse_pos.y()

        # 鼠标位置对应的世界坐标（使用当前 zoom）
        wr, wc = self.screen_to_world(mx, my)

        # 计算新的 offset，使得鼠标下的世界坐标不变
        self.offset_x = mx - wc * self.base_cell_size * new_zoom
        self.offset_y = my - wr * self.base_cell_size * new_zoom
        self.zoom = new_zoom

        self.update()
        event.accept()

    # -------------------- 游戏逻辑（基于稀疏集 + numpy）--------------------
    def next_generation(self):
        rows, cols = self.rows, self.cols
        live_set = {r * cols + c for r, c in self.live_cells}
        if not live_set:
            return

        # 八个邻居偏移
        deltas = [(-1, -1), (-1, 0), (-1, 1),
                  (0, -1),           (0, 1),
                  (1, -1),  (1, 0),  (1, 1)]

        neighbors = []
        for code in live_set:
            r = code // cols
            c = code % cols
            for dr, dc in deltas:
                nr = r + dr
                nc = c + dc
                if self.boundary == 'wrap':
                    nr %= rows
                    nc %= cols
                    neighbors.append(nr * cols + nc)
                else:  # fixed
                    if 0 <= nr < rows and 0 <= nc < cols:
                        neighbors.append(nr * cols + nc)

        if not neighbors:
            # 没有邻居，下一代全灭
            self.live_cells.clear()
            self.update()
            self.grid_changed.emit()
            return

        # 使用 numpy 统计邻居出现次数
        neighbors = np.array(neighbors, dtype=np.int64)
        codes, counts = np.unique(neighbors, return_counts=True)

        # 构建下一代存活编码集合
        next_live = set()

        # 规则1：任何有3个活邻居的细胞变为活（无论原来死活）
        mask3 = counts == 3
        next_live.update(codes[mask3].tolist())

        # 规则2：任何有2个活邻居的细胞，如果原来就是活的，则继续活
        mask2 = counts == 2
        for code in codes[mask2]:
            if code in live_set:
                next_live.add(code)

        # 解码回坐标集合
        self.live_cells = {(code // cols, code % cols) for code in next_live}
        self.update()
        self.grid_changed.emit()

    def randomize(self):
        """随机生成存活细胞（密度控制）"""
        total_cells = self.rows * self.cols
        target = int(total_cells * self.density)
        # 如果目标太大，限制一下，避免内存爆炸（最多生成500万个细胞）
        target = min(target, 5_000_000)

        live_set = set()
        # 批量生成随机坐标，直到达到目标数量
        batch_size = 10000
        while len(live_set) < target:
            # 生成 batch_size 个随机整数坐标编码
            codes = np.random.randint(0, total_cells, size=batch_size)
            # 去重并添加
            live_set.update(codes.tolist())
            # 如果已超过 target，截断
            if len(live_set) > target:
                # 随机选择 target 个
                live_set = set(random.sample(live_set, target))

        # 解码为坐标
        self.live_cells = {(code // self.cols, code % self.cols) for code in live_set}
        self.update()
        self.grid_changed.emit()

    def clear(self):
        self.live_cells.clear()
        self.update()
        self.grid_changed.emit()

    def count_live(self):
        return len(self.live_cells)

    def apply_pattern(self, pattern, offset_row, offset_col):
        """应用图案（pattern 为 (r,c) 列表）"""
        for r, c in pattern:
            wr = offset_row + r
            wc = offset_col + c
            if 0 <= wr < self.rows and 0 <= wc < self.cols:
                self.live_cells.add((wr, wc))
        self.update()
        self.grid_changed.emit()


class PresetEditor(QDialog):
    """预设编辑窗口（100×100画布，支持缩放/平移，左键绘制）"""
    def __init__(self, parent=None, pattern=None, preset_name=""):
        super().__init__(parent)
        self.parent = parent
        self.setWindowTitle("预设编辑器")
        self.setModal(True)
        # 调整对话框最小尺寸，适应更小的编辑区
        self.setMinimumSize(800, 600)

        # 编辑画布 (100x100，格子大小16像素，启用视图变换)
        self.editor = GameOfLife(rows=100, cols=100, cell_size=16, parent=self, enable_view_transform=True)
        self.editor.show_grid = True
        self.editor.boundary = 'fixed'  # 固定边界，避免图案环绕

        # 如果有传入图案，加载到画布
        if pattern:
            for r, c in pattern:
                if 0 <= r < self.editor.rows and 0 <= c < self.editor.cols:
                    self.editor.live_cells.add((r, c))
            self.editor.update()

        # 名称输入
        self.name_edit = QLineEdit()
        self.name_edit.setText(preset_name)
        self.name_edit.setPlaceholderText("输入预设名称")

        # 按钮
        btn_clear = QPushButton("清除")
        btn_random = QPushButton("随机")
        btn_save = QPushButton("保存")
        btn_cancel = QPushButton("取消")

        # 滚动区域（只包含画布）
        scroll = QScrollArea()
        scroll.setWidget(self.editor)
        scroll.setWidgetResizable(True)
        scroll.setAlignment(Qt.AlignCenter)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setMinimumHeight(400)  # 保证画布区域有足够空间

        # 布局
        layout = QVBoxLayout(self)
        layout.addWidget(scroll)

        hbox = QHBoxLayout()
        hbox.addWidget(btn_clear)
        hbox.addWidget(btn_random)
        hbox.addStretch()
        layout.addLayout(hbox)

        form_layout = QHBoxLayout()
        form_layout.addWidget(QLabel("名称:"))
        form_layout.addWidget(self.name_edit)
        layout.addLayout(form_layout)

        btn_box = QHBoxLayout()
        btn_box.addStretch()
        btn_box.addWidget(btn_save)
        btn_box.addWidget(btn_cancel)
        layout.addLayout(btn_box)

        # 信号连接
        btn_clear.clicked.connect(self.editor.clear)
        btn_random.clicked.connect(self.editor.randomize)
        btn_save.clicked.connect(self.save_preset)
        btn_cancel.clicked.connect(self.reject)

        # 应用样式
        self.setStyleSheet(parent.styleSheet() if parent else "")

    def save_preset(self):
        name = self.name_edit.text().strip()
        if not name:
            QMessageBox.warning(self, "警告", "预设名称不能为空！")
            return

        # 收集存活细胞坐标
        pattern = []
        for r, c in self.editor.live_cells:
            pattern.append([r, c])

        if not pattern:
            QMessageBox.warning(self, "警告", "图案不能为空！")
            return

        # 确保自定义目录存在
        os.makedirs(self.parent.custom_patterns_dir, exist_ok=True)

        # 生成文件名（替换非法字符）
        safe_name = "".join(c for c in name if c.isalnum() or c in (' ', '-', '_')).rstrip()
        if not safe_name:
            safe_name = "unnamed"
        filename = os.path.join(self.parent.custom_patterns_dir, f"{safe_name}.json")

        # 如果文件已存在，询问是否覆盖
        if os.path.exists(filename):
            reply = QMessageBox.question(self, "确认覆盖",
                                         f"文件 {safe_name}.json 已存在，是否覆盖？",
                                         QMessageBox.Yes | QMessageBox.No)
            if reply != QMessageBox.Yes:
                return

        # 写入 JSON
        data = {"name": name, "pattern": pattern}
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

        # 通知主窗口重新加载自定义预设
        self.parent.reload_custom_patterns()
        self.accept()


class SettingsDialog(QDialog):
    """设置窗口，包含绘制选项、预设管理、外观三个标签页"""
    def __init__(self, parent):
        super().__init__(parent)
        self.parent = parent  # MainWindow实例
        self.setWindowTitle("设置")
        self.setMinimumSize(800, 600)
        self.setStyleSheet(parent.styleSheet())  # 继承主窗口样式

        # 创建标签页
        tab_widget = QTabWidget(self)

        # ----- 绘制选项标签页 -----
        draw_tab = QWidget()
        tab_widget.addTab(draw_tab, "绘制选项")
        draw_layout = QVBoxLayout(draw_tab)

        # 绘制模式
        mode_group = QGroupBox("绘制模式")
        mode_layout = QHBoxLayout(mode_group)
        self.draw_mode_group = QButtonGroup(self)
        self.rb_toggle = QRadioButton("切换")
        self.rb_live = QRadioButton("画活")
        self.rb_dead = QRadioButton("画死")
        self.draw_mode_group.addButton(self.rb_toggle, 1)
        self.draw_mode_group.addButton(self.rb_live, 2)
        self.draw_mode_group.addButton(self.rb_dead, 3)
        mode_layout.addWidget(self.rb_toggle)
        mode_layout.addWidget(self.rb_live)
        mode_layout.addWidget(self.rb_dead)
        mode_layout.addStretch()
        draw_layout.addWidget(mode_group)

        # 边界条件
        boundary_group = QGroupBox("边界条件")
        boundary_layout = QHBoxLayout(boundary_group)
        boundary_layout.addWidget(QLabel("边界类型:"))
        self.boundary_combo = QComboBox()
        self.boundary_combo.addItem("环形", "wrap")
        self.boundary_combo.addItem("固定", "fixed")
        boundary_layout.addWidget(self.boundary_combo)
        boundary_layout.addStretch()
        draw_layout.addWidget(boundary_group)

        # 随机密度
        density_group = QGroupBox("随机密度")
        density_layout = QHBoxLayout(density_group)
        density_layout.addWidget(QLabel("密度:"))
        self.density_slider = QSlider(Qt.Horizontal)
        self.density_slider.setRange(10, 90)
        self.density_slider.setValue(30)
        self.density_slider.setFixedWidth(200)
        self.density_slider.setTickInterval(10)
        self.density_slider.setTickPosition(QSlider.TicksBelow)
        density_layout.addWidget(self.density_slider)
        self.density_label = QLabel("30%")
        density_layout.addWidget(self.density_label)
        density_layout.addStretch()
        draw_layout.addWidget(density_group)

        # 显示网格
        grid_group = QGroupBox("显示选项")
        grid_layout = QHBoxLayout(grid_group)
        self.grid_check = QCheckBox("显示网格线")
        self.grid_check.setChecked(True)
        grid_layout.addWidget(self.grid_check)
        grid_layout.addStretch()
        draw_layout.addWidget(grid_group)

        draw_layout.addStretch()

        # ----- 预设管理标签页 -----
        preset_tab = QWidget()
        tab_widget.addTab(preset_tab, "预设管理")
        preset_layout = QVBoxLayout(preset_tab)

        # 操作按钮：新建、编辑
        btn_layout = QHBoxLayout()
        self.btn_new_preset = QPushButton("新建")
        self.btn_edit_preset = QPushButton("编辑")
        btn_layout.addWidget(self.btn_new_preset)
        btn_layout.addWidget(self.btn_edit_preset)
        btn_layout.addStretch()
        preset_layout.addLayout(btn_layout)

        # 预设列表
        preset_list_label = QLabel("所有预设（双击应用，右键删除自定义）")
        preset_layout.addWidget(preset_list_label)

        self.preset_list = QListWidget()
        self.preset_list.setContextMenuPolicy(Qt.CustomContextMenu)
        self.preset_list.customContextMenuRequested.connect(self.show_preset_context_menu)
        self.preset_list.itemDoubleClicked.connect(self.apply_preset_from_list)
        self.populate_preset_list()
        preset_layout.addWidget(self.preset_list)

        # ----- 外观设置标签页 -----
        appearance_tab = QWidget()
        tab_widget.addTab(appearance_tab, "外观")
        appearance_layout = QVBoxLayout(appearance_tab)

        # 存活颜色
        live_color_group = QGroupBox("存活细胞颜色")
        live_color_layout = QHBoxLayout(live_color_group)
        self.live_color_label = QLabel()
        self.live_color_label.setFixedSize(50, 30)
        self.live_color_label.setStyleSheet("background-color: rgb(100,255,100); border: 1px solid gray;")
        self.live_color_btn = QPushButton("选择颜色")
        live_color_layout.addWidget(self.live_color_label)
        live_color_layout.addWidget(self.live_color_btn)
        live_color_layout.addStretch()
        appearance_layout.addWidget(live_color_group)

        # 背景颜色
        dead_color_group = QGroupBox("背景颜色")
        dead_color_layout = QHBoxLayout(dead_color_group)
        self.dead_color_label = QLabel()
        self.dead_color_label.setFixedSize(50, 30)
        self.dead_color_label.setStyleSheet("background-color: rgb(30,30,30); border: 1px solid gray;")
        self.dead_color_btn = QPushButton("选择颜色")
        dead_color_layout.addWidget(self.dead_color_label)
        dead_color_layout.addWidget(self.dead_color_btn)
        dead_color_layout.addStretch()
        appearance_layout.addWidget(dead_color_group)

        # 网格颜色
        grid_color_group = QGroupBox("网格颜色")
        grid_color_layout = QHBoxLayout(grid_color_group)
        self.grid_color_label = QLabel()
        self.grid_color_label.setFixedSize(50, 30)
        self.grid_color_label.setStyleSheet("background-color: rgb(60,60,60); border: 1px solid gray;")
        self.grid_color_btn = QPushButton("选择颜色")
        grid_color_layout.addWidget(self.grid_color_label)
        grid_color_layout.addWidget(self.grid_color_btn)
        grid_color_layout.addStretch()
        appearance_layout.addWidget(grid_color_group)

        appearance_layout.addStretch()

        # 主布局
        main_layout = QVBoxLayout(self)
        main_layout.addWidget(tab_widget)

        # 连接信号
        self.connect_signals()

        # 初始化UI以匹配当前游戏状态
        self.update_ui_from_game()

    def connect_signals(self):
        """连接控件信号到对应的槽函数"""
        # 绘制模式
        self.rb_toggle.toggled.connect(self.on_draw_mode_changed)
        self.rb_live.toggled.connect(self.on_draw_mode_changed)
        self.rb_dead.toggled.connect(self.on_draw_mode_changed)

        # 边界
        self.boundary_combo.currentIndexChanged.connect(self.on_boundary_changed)

        # 密度
        self.density_slider.valueChanged.connect(self.on_density_changed)

        # 显示网格
        self.grid_check.stateChanged.connect(self.on_show_grid_changed)

        # 颜色
        self.live_color_btn.clicked.connect(lambda: self.choose_color('live'))
        self.dead_color_btn.clicked.connect(lambda: self.choose_color('dead'))
        self.grid_color_btn.clicked.connect(lambda: self.choose_color('grid'))

        # 预设管理
        self.btn_new_preset.clicked.connect(self.new_preset)
        self.btn_edit_preset.clicked.connect(self.edit_preset)

    def update_ui_from_game(self):
        """根据当前游戏状态更新UI控件的值"""
        game = self.parent.game

        # 绘制模式
        if game.draw_mode == 'toggle':
            self.rb_toggle.setChecked(True)
        elif game.draw_mode == 'live':
            self.rb_live.setChecked(True)
        else:
            self.rb_dead.setChecked(True)

        # 边界
        index = self.boundary_combo.findData(game.boundary)
        if index >= 0:
            self.boundary_combo.setCurrentIndex(index)

        # 密度
        density_val = int(game.density * 100)
        self.density_slider.setValue(density_val)
        self.density_label.setText(f"{density_val}%")

        # 显示网格
        self.grid_check.setChecked(game.show_grid)

        # 颜色
        self.live_color_label.setStyleSheet(f"background-color: {game.live_color.name()}; border: 1px solid gray;")
        self.dead_color_label.setStyleSheet(f"background-color: {game.dead_color.name()}; border: 1px solid gray;")
        self.grid_color_label.setStyleSheet(f"background-color: {game.grid_color.name()}; border: 1px solid gray;")

    # ---------- 绘制选项槽函数 ----------
    def on_draw_mode_changed(self):
        if self.rb_toggle.isChecked():
            self.parent.game.draw_mode = 'toggle'
        elif self.rb_live.isChecked():
            self.parent.game.draw_mode = 'live'
        else:
            self.parent.game.draw_mode = 'dead'

    def on_boundary_changed(self, index):
        self.parent.game.boundary = self.boundary_combo.currentData()

    def on_density_changed(self, value):
        self.parent.game.density = value / 100.0
        self.density_label.setText(f"{value}%")

    def on_show_grid_changed(self, state):
        self.parent.game.show_grid = (state == Qt.Checked)
        self.parent.game.update()

    def choose_color(self, target):
        color = QColorDialog.getColor()
        if color.isValid():
            game = self.parent.game
            if target == 'live':
                game.live_color = color
                self.live_color_label.setStyleSheet(f"background-color: {color.name()}; border: 1px solid gray;")
            elif target == 'dead':
                game.dead_color = color
                self.dead_color_label.setStyleSheet(f"background-color: {color.name()}; border: 1px solid gray;")
            elif target == 'grid':
                game.grid_color = color
                self.grid_color_label.setStyleSheet(f"background-color: {color.name()}; border: 1px solid gray;")
            game.update()

    # ---------- 预设管理 ----------
    def populate_preset_list(self):
        """填充预设列表"""
        self.preset_list.clear()
        # 内置预设
        for name, pattern in self.parent.builtin_patterns.items():
            item = QListWidgetItem(f"📦 {name}")
            item.setData(Qt.UserRole, ('builtin', name, pattern))
            self.preset_list.addItem(item)
        # 自定义预设
        for key, data in self.parent.custom_patterns.items():
            item = QListWidgetItem(f"✏️ {data['display']}")
            item.setData(Qt.UserRole, ('custom', key, data['pattern']))
            self.preset_list.addItem(item)

    def apply_preset_from_list(self, item):
        """从列表应用预设"""
        data = item.data(Qt.UserRole)
        if data:
            _, _, pattern = data
            self.parent._apply_pattern_to_center(pattern)

    def new_preset(self):
        """新建预设"""
        dlg = PresetEditor(self.parent)
        dlg.exec_()
        self.refresh_preset_controls()

    def edit_preset(self):
        """编辑当前选中的预设"""
        current_item = self.preset_list.currentItem()
        if not current_item:
            QMessageBox.information(self, "提示", "请先选择一个预设。")
            return
        data = current_item.data(Qt.UserRole)
        if not data:
            return
        ptype, key_or_name, pattern = data
        if ptype == 'builtin':
            name_hint = key_or_name + " (副本)"
        else:
            name_hint = key_or_name + " (编辑)"

        dlg = PresetEditor(self.parent, pattern, name_hint)
        dlg.exec_()
        self.refresh_preset_controls()

    def show_preset_context_menu(self, pos):
        """右键菜单，仅对自定义预设显示删除选项"""
        item = self.preset_list.itemAt(pos)
        if not item:
            return
        data = item.data(Qt.UserRole)
        if not data:
            return
        ptype, key, _ = data
        if ptype == 'builtin':
            return  # 内置预设不可删除

        menu = QMenu()
        delete_action = QAction("删除自定义预设", self)
        delete_action.triggered.connect(lambda: self.delete_custom_preset(key))
        menu.addAction(delete_action)
        menu.exec_(self.preset_list.mapToGlobal(pos))

    def delete_custom_preset(self, key):
        """删除指定的自定义预设"""
        reply = QMessageBox.question(self, "确认删除",
                                     f"确定要删除自定义预设“{key}”吗？",
                                     QMessageBox.Yes | QMessageBox.No)
        if reply == QMessageBox.Yes:
            filename = os.path.join(self.parent.custom_patterns_dir, f"{key}.json")
            if os.path.exists(filename):
                os.remove(filename)
            self.parent.reload_custom_patterns()
            self.refresh_preset_controls()

    def refresh_preset_controls(self):
        """刷新预设列表（主界面的下拉框也会在reload时自动更新）"""
        self.populate_preset_list()
        self.parent.populate_preset_combo()  # 同步主界面的下拉框


class MainWindow(QMainWindow):
    """主窗口"""
    def __init__(self):
        super().__init__()
        self.setWindowTitle("康威生命游戏")
        self.setMinimumSize(1000, 750)

        # 预设目录
        self.builtin_patterns_dir = "builtin_patterns"
        self.custom_patterns_dir = "custom_patterns"
        os.makedirs(self.builtin_patterns_dir, exist_ok=True)
        os.makedirs(self.custom_patterns_dir, exist_ok=True)

        # 初始化内置预设（若无则创建默认文件）
        self.ensure_builtin_patterns()

        # 加载预设
        self.builtin_patterns = {}  # {显示名: 坐标列表}
        self.custom_patterns = {}   # {文件名键: {"display": 显示名, "pattern": 坐标列表}}
        self.load_builtin_patterns()
        self.load_custom_patterns()

        # 中央部件和主布局
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)
        main_layout.setContentsMargins(10, 10, 10, 10)
        main_layout.setSpacing(10)

        # 游戏画布（10000x10000，启用视图变换）
        self.game = GameOfLife(rows=10000, cols=10000, cell_size=12, parent=self, enable_view_transform=True)
        main_layout.addWidget(self.game, 1)  # 拉伸因子为1，占据剩余空间

        # ========== 核心控制栏（顶部） ==========
        top_panel = QWidget()
        top_layout = QHBoxLayout(top_panel)
        top_layout.setSpacing(15)

        self.btn_start = QPushButton("开始")
        self.btn_start.setFixedSize(80, 30)
        self.btn_start.clicked.connect(self.toggle_simulation)
        top_layout.addWidget(self.btn_start)

        self.btn_step = QPushButton("步进")
        self.btn_step.setFixedSize(80, 30)
        self.btn_step.clicked.connect(self.step)
        top_layout.addWidget(self.btn_step)

        self.btn_random = QPushButton("随机")
        self.btn_random.setFixedSize(80, 30)
        self.btn_random.clicked.connect(self.game.randomize)
        top_layout.addWidget(self.btn_random)

        self.btn_clear = QPushButton("清除")
        self.btn_clear.setFixedSize(80, 30)
        self.btn_clear.clicked.connect(self.game.clear)
        top_layout.addWidget(self.btn_clear)

        # 预设选择和应用
        self.preset_combo = QComboBox()
        self.preset_combo.setFixedWidth(150)
        self.populate_preset_combo()
        top_layout.addWidget(self.preset_combo)

        self.btn_apply_preset = QPushButton("应用")
        self.btn_apply_preset.setFixedSize(60, 30)
        self.btn_apply_preset.clicked.connect(self.apply_selected_preset)
        top_layout.addWidget(self.btn_apply_preset)

        # ========== 新增：居中按钮 ==========
        self.btn_center = QPushButton("居中")
        self.btn_center.setFixedSize(60, 30)
        self.btn_center.clicked.connect(self.center_view)
        top_layout.addWidget(self.btn_center)

        # 设置按钮
        self.btn_settings = QPushButton("设置")
        self.btn_settings.setFixedSize(80, 30)
        self.btn_settings.clicked.connect(self.open_settings_dialog)
        top_layout.addWidget(self.btn_settings)

        top_layout.addWidget(QLabel("速度"))
        self.speed_slider = QSlider(Qt.Horizontal)
        self.speed_slider.setRange(10, 200)
        self.speed_slider.setValue(50)
        self.speed_slider.setFixedWidth(150)
        self.speed_slider.setTickInterval(10)
        self.speed_slider.setTickPosition(QSlider.TicksBelow)
        top_layout.addWidget(self.speed_slider)

        self.generation_label = QLabel("代数: 0")
        top_layout.addWidget(self.generation_label)

        self.live_count_label = QLabel("存活: 0")
        top_layout.addWidget(self.live_count_label)

        top_layout.addStretch()
        main_layout.addWidget(top_panel)

        # 定时器
        self.timer = QTimer()
        self.timer.timeout.connect(self.next_generation)
        self.generation = 0
        self.running = False

        # 连接游戏信号
        self.game.grid_changed.connect(self.update_stats)

        # 初始统计更新
        self.update_stats()

        # 应用样式表
        self.apply_stylesheet()

    # ========== 新增：居中视图槽函数 ==========
    def center_view(self):
        """将视图中心定位到世界中心 (5000,5000)"""
        self.game.center_view(self.game.rect())

    # ---------- 内置预设初始化（使用用户提供的JSON数据）----------
    def ensure_builtin_patterns(self):
        """如果 builtin_patterns 目录为空，则创建用户提供的默认预设文件"""
        if os.listdir(self.builtin_patterns_dir):
            return  # 目录非空，不做操作

        # 用户提供的预设数据
        default_patterns = {
            "蟾蜍": {
                "name": "蟾蜍",
                "pattern": [[0,1], [1,2], [2,0], [1,0], [1,1], [1,2]]
            },
            "滑翔机": {
                "name": "滑翔机",
                "pattern": [[0,1], [1,2], [2,0], [2,1], [2,2]]
            },
            "蜂王巡": {
                "name": "蜂王巡",
                "pattern": [
                    [0,9], [1,7], [1,9], [2,6], [2,8], [3,0], [3,1], [3,5], [3,8], [3,20], [3,21],
                    [4,0], [4,1], [4,6], [4,8], [4,20], [4,21], [5,7], [5,9], [6,9]
                ]
            },
            "共振器": {
                "name": "共振器",
                "pattern": [
                    [0,0],[0,1],[0,2],[0,3],[0,4],[0,5],[0,7],[0,8],
                    [1,0],[1,1],[1,2],[1,3],[1,4],[1,5],[1,7],[1,8],
                    [2,7],[2,8],
                    [3,0],[3,1],[3,7],[3,8],
                    [4,0],[4,1],[4,7],[4,8],
                    [5,0],[5,1],[5,7],[5,8],
                    [6,0],[6,1],
                    [7,0],[7,1],[7,3],[7,4],[7,5],[7,6],[7,7],[7,8],
                    [8,0],[8,1],[8,3],[8,4],[8,5],[8,6],[8,7],[8,8]
                ]
            },
            "脉冲星": {
                "name": "脉冲星",
                "pattern": [
                    [0,2],[0,3],[0,4],[0,8],[0,9],[0,10],
                    [2,0],[2,5],[2,7],[2,12],
                    [3,0],[3,5],[3,7],[3,12],
                    [4,0],[4,5],[4,7],[4,12],
                    [5,2],[5,3],[5,4],[5,8],[5,9],[5,10],
                    [7,2],[7,3],[7,4],[7,8],[7,9],[7,10],
                    [8,0],[8,5],[8,7],[8,12],
                    [9,0],[9,5],[9,7],[9,12],
                    [10,0],[10,5],[10,7],[10,12],
                    [12,2],[12,3],[12,4],[12,8],[12,9],[12,10]
                ]
            },
            "轻量级飞船": {
                "name": "轻量级飞船 (LWSS)",
                "pattern": [
                    [0,0],[0,3],
                    [1,4],
                    [2,0],[2,4],
                    [3,1],[3,2],[3,3],[3,4]
                ]
            },
            "宇宙飞船": {
                "name": "宇宙飞船",
                "pattern": [
                    [0,1],[0,2],
                    [1,0],[1,1],[1,2],[1,3],
                    [2,0],[2,1],[2,3],[2,4],
                    [3,2],[3,3]
                ]
            }
        }

        for key, data in default_patterns.items():
            filename = os.path.join(self.builtin_patterns_dir, f"{key}.json")
            with open(filename, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)

    # ---------- 预设加载 ----------
    def load_builtin_patterns(self):
        """从 builtin_patterns 文件夹加载内置预设"""
        self.builtin_patterns.clear()
        for filename in os.listdir(self.builtin_patterns_dir):
            if filename.lower().endswith('.json'):
                filepath = os.path.join(self.builtin_patterns_dir, filename)
                try:
                    with open(filepath, 'r', encoding='utf-8') as f:
                        data = json.load(f)
                    name = data.get('name', os.path.splitext(filename)[0])
                    pattern = data.get('pattern', [])
                    # 转换为元组列表以保持一致性
                    pattern = [(r, c) for r, c in pattern]
                    self.builtin_patterns[name] = pattern
                except Exception as e:
                    print(f"加载内置预设失败 {filename}: {e}")

    def load_custom_patterns(self):
        """从 custom_patterns 文件夹加载自定义预设"""
        self.custom_patterns.clear()
        if not os.path.exists(self.custom_patterns_dir):
            return
        for filename in os.listdir(self.custom_patterns_dir):
            if filename.lower().endswith('.json'):
                filepath = os.path.join(self.custom_patterns_dir, filename)
                try:
                    with open(filepath, 'r', encoding='utf-8') as f:
                        data = json.load(f)
                    name = data.get('name', os.path.splitext(filename)[0])
                    pattern = data.get('pattern', [])
                    pattern = [(r, c) for r, c in pattern]
                    key = os.path.splitext(filename)[0]
                    self.custom_patterns[key] = {'display': name, 'pattern': pattern}
                except Exception as e:
                    print(f"加载自定义预设失败 {filename}: {e}")

    def reload_custom_patterns(self):
        """重新加载自定义预设并更新UI"""
        self.load_custom_patterns()
        self.populate_preset_combo()
        # 如果设置窗口已打开，也需要刷新其列表；但设置窗口可以通过其内部的 refresh 独立完成，这里不做处理

    def populate_preset_combo(self):
        """填充主界面的预设下拉框（内置 + 自定义）"""
        self.preset_combo.clear()
        # 内置预设
        for name, pattern in self.builtin_patterns.items():
            self.preset_combo.addItem(name, userData=pattern)
        # 如果有自定义预设，添加分隔线
        if self.custom_patterns:
            self.preset_combo.insertSeparator(self.preset_combo.count())
            for key, data in self.custom_patterns.items():
                display = f"[自定义] {data['display']}"
                self.preset_combo.addItem(display, userData=data['pattern'])

    # ---------- 预设操作 ----------
    def apply_selected_preset(self):
        """应用主界面下拉框选中的预设"""
        idx = self.preset_combo.currentIndex()
        pattern = self.preset_combo.itemData(idx)
        if pattern:
            self._apply_pattern_to_center(pattern)

    def _apply_pattern_to_center(self, pattern):
        """将图案应用到网格中心"""
        if not pattern:
            return
        rows = max(r for r, _ in pattern) + 1
        cols = max(c for _, c in pattern) + 1
        start_row = (self.game.rows - rows) // 2
        start_col = (self.game.cols - cols) // 2
        self.game.apply_pattern(pattern, start_row, start_col)

    def open_preset_editor(self, pattern=None, name=""):
        """打开预设编辑器（供设置窗口调用）"""
        dlg = PresetEditor(self, pattern, name)
        dlg.exec_()

    # ---------- 信号处理 ----------
    def update_stats(self):
        count = self.game.count_live()
        self.live_count_label.setText(f"存活: {count}")

    def toggle_simulation(self):
        if self.running:
            self.timer.stop()
            self.btn_start.setText("开始")
        else:
            interval = self.speed_slider.value()
            self.timer.start(interval)
            self.btn_start.setText("暂停")
        self.running = not self.running

    def step(self):
        was_running = self.running
        if was_running:
            self.toggle_simulation()
        self.next_generation()
        if was_running:
            self.toggle_simulation()

    def next_generation(self):
        self.game.next_generation()
        self.generation += 1
        self.generation_label.setText(f"代数: {self.generation}")

    def closeEvent(self, event):
        self.timer.stop()
        event.accept()

    def open_settings_dialog(self):
        """打开设置窗口"""
        dlg = SettingsDialog(self)
        dlg.exec_()

    # ---------- 样式表 ----------
    def apply_stylesheet(self):
        self.setStyleSheet("""
            QMainWindow { background-color: #1e1e1e; }
            QWidget {
                background-color: #2d2d2d;
                color: #f0f0f0;
                font-family: "Segoe UI", "Microsoft YaHei", sans-serif;
                font-size: 10pt;
            }
            QPushButton {
                background-color: #3c3c3c;
                border: 1px solid #555;
                border-radius: 4px;
                padding: 5px;
                color: #ffffff;
            }
            QPushButton:hover {
                background-color: #4e4e4e;
                border: 1px solid #0078d7;
            }
            QPushButton:pressed {
                background-color: #2e2e2e;
            }
            QRadioButton {
                color: #cccccc;
                spacing: 5px;
            }
            QRadioButton::indicator {
                width: 15px;
                height: 15px;
                border-radius: 7px;
                background: #3c3c3c;
                border: 1px solid #555;
            }
            QRadioButton::indicator:checked {
                background: #0078d7;
                border: 1px solid #0078d7;
            }
            QComboBox {
                background-color: #3c3c3c;
                border: 1px solid #555;
                border-radius: 4px;
                padding: 4px;
                color: #ffffff;
            }
            QComboBox:hover {
                border: 1px solid #0078d7;
            }
            QComboBox::drop-down {
                subcontrol-origin: padding;
                subcontrol-position: top right;
                width: 20px;
                border-left: 1px solid #555;
            }
            QCheckBox {
                color: #cccccc;
                spacing: 5px;
            }
            QCheckBox::indicator {
                width: 15px;
                height: 15px;
                background: #3c3c3c;
                border: 1px solid #555;
                border-radius: 3px;
            }
            QCheckBox::indicator:checked {
                background: #0078d7;
                border: 1px solid #0078d7;
            }
            QSlider::groove:horizontal {
                border: 1px solid #444;
                height: 6px;
                background: #2a2a2a;
                margin: 2px 0;
                border-radius: 3px;
            }
            QSlider::handle:horizontal {
                background: #0078d7;
                border: 1px solid #0078d7;
                width: 14px;
                height: 14px;
                margin: -5px 0;
                border-radius: 7px;
            }
            QSlider::handle:horizontal:hover {
                background: #1a86d9;
            }
            QLabel {
                color: #cccccc;
            }
            QScrollArea {
                border: none;
                background-color: #1e1e1e;
            }
            QLineEdit {
                background-color: #3c3c3c;
                border: 1px solid #555;
                border-radius: 4px;
                padding: 4px;
                color: #ffffff;
            }
            QListWidget {
                background-color: #3c3c3c;
                border: 1px solid #555;
                border-radius: 4px;
                color: #ffffff;
            }
            QTabWidget::pane {
                border: 1px solid #555;
                background-color: #2d2d2d;
            }
            QTabBar::tab {
                background-color: #3c3c3c;
                color: #cccccc;
                padding: 8px 12px;
                margin-right: 2px;
                border-top-left-radius: 4px;
                border-top-right-radius: 4px;
            }
            QTabBar::tab:selected {
                background-color: #0078d7;
                color: white;
            }
            QGroupBox {
                border: 1px solid #555;
                border-radius: 4px;
                margin-top: 0.5em;
                padding-top: 0.5em;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 5px 0 5px;
                color: #cccccc;
            }
        """)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())